import gradio as gr
from gradio.components import Markdown as md
from PIL import Image

demo = gr.Blocks()

io1a = gr.Interface(lambda x: x, gr.Image(), gr.Image())


def upload_file(files):
  file_paths = [file.name for file in files]
  return file_paths

with demo:

    io1a.render()

gr.Interface(
    file_output = gr.File(),
    upload_button = gr.UploadButton("Click to Upload a File", file_types=["image", "video"], file_count="multiple"),
    upload_button.upload(upload_file, upload_button, file_output)
  )


if __name__ == "__main__":
    demo.launch(share=True)


